import sys
sys.path.append("../lib")
from crazyradio import Crazyradio

radio = Crazyradio()
radio.set_channel(50)
radio.set_data_rate(Crazyradio.DR_2MPS)
radio.set_mode(Crazyradio.MODE_PTX)
radio.set_address((0xE7,)*4+(0x01,))
for i in range(1, 2):
	res = radio.send_packet([i])
        print(res.data)
radio.close()
