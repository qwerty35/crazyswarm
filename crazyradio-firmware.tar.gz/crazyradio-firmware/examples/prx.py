import sys
sys.path.append("../lib")
from crazyradio import Crazyradio

radio = Crazyradio()
radio.set_channel(50)
radio.set_data_rate(Crazyradio.DR_250KPS)
radio.set_mode(Crazyradio.MODE_PRX)
radio.set_address((0xE7,)*4+(0x01,))
for i in range(0, 100):
	res = radio.receive()
	if res:
		radio.sendAck([i])
	print(res)
radio.close()
